//
//  CCCartoonMakerViewController.m
//  CrazyCartoon
//
//  Created by Tarena on 16/4/18.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "CCCartoonMakerViewController.h"
#import "CCPictureList.h"
#import "ImageView.h"
#import "ImageViewController.h"

/** 屏幕宽 */
#define kScreenW [UIScreen mainScreen].bounds.size.width
/** itemtag */
#define kItemIconTag 100;

@interface CCCartoonMakerViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate>
/** 计算属性 */
@property (nonatomic) CGFloat lineSpace;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;
/** 图片列表 */
@property (nonatomic, strong) CCPictureList *pictureList;
@property (nonatomic, strong) NSArray *list;
@property (weak, nonatomic) IBOutlet UIView *pictureMakerView;
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIPanGestureRecognizer *pan;

@property (weak, nonatomic) IBOutlet UIView *writeWordView;
- (IBAction)writeWordBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *writeWordTextField;


@property(nonatomic,strong)ImageViewController* ima;
@property(nonatomic,strong)NSMutableArray* pictureArray;
@property(nonatomic,strong)UIImageView* imv;


@end

@implementation CCCartoonMakerViewController
-(NSMutableArray *)pictureArray
{
    if (_pictureArray) {
        _pictureArray = [NSMutableArray array];
    }
    return _pictureArray;
}
-(NSArray *)list{
    if (!_list) {
        _list = [CCPictureList getPictureList];
    }
    return _list;
}
- (CGFloat)lineSpace{
    
    return (kScreenW - 6*50)/6;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.imageView.userInteractionEnabled = YES;
    _pageControl.numberOfPages = (self.list.count+17)/18;
    self.automaticallyAdjustsScrollViewInsets = NO;

    
    _ima = [[ImageViewController alloc]init];
    _ima.view.frame = self.pictureMakerView.frame;
    CGRect rect = _ima.view.frame;
    rect.origin.x = rect.origin.x+2;
    rect.origin.y = rect.origin.y+2;
    rect.size.width = rect.size.width - 4;
    rect.size.height = rect.size.height - 4;
    _ima.view.frame = rect;
    [self.view addSubview:_ima.view];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    for (UIView* a in self.pictureMakerView.subviews) {
        if (!([a isKindOfClass:[ImageView class]]||[a isKindOfClass:[UILabel class]])) {
            [a removeFromSuperview];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIScrollView Delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == _collectionView) {
        _pageControl.currentPage = _collectionView.contentOffset.x / kScreenW + 0.5;
    }
}

#pragma mark - UICollectionView Delegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    UIImage *image = [UIImage new];
    image = self.list[indexPath.row];

    NSNotificationCenter* nc= [NSNotificationCenter defaultCenter];
    NSMutableDictionary* msg = [[NSDictionary dictionary] mutableCopy];
    msg[@"imageName"] = image;
    [nc postNotificationName:@"sendMsg" object:self userInfo:msg];
    
//    self.category = [self.mainVM titleForIndex:indexPath.row];
//    [self.businessVM getBusinessWithCategory:self.category requestMode:RequestModeRefresh completionHandler:^(NSError *error) {
//        [self.view hideBusyHUD];
//        if (error) {
//            [self.view showWarning:error.localizedDescription];
//        }else{
//            [self.tableView reloadData];
//        }
//    }];
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.list.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"item" forIndexPath:indexPath];
    UIImage *image = self.list[indexPath.row];
    UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectMake(5, 5, 40, 40)];
    imageV.image = image;
    [cell.contentView addSubview:imageV];
    return cell;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return self.lineSpace;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(0, self.lineSpace/2, 0, self.lineSpace/2);
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)finishWriting:(id)sender {
    NSNotificationCenter* nc= [NSNotificationCenter defaultCenter];
    NSMutableDictionary* wordDic = [[NSDictionary dictionary] mutableCopy];
    wordDic[@"word"] = self.writeWordTextField.text;
    [nc postNotificationName:@"writeWord" object:self userInfo:wordDic];
//    UILabel *label = [[UILabel alloc]init];
//    label.text = self.writeWordTextField.text;
//    [self.ima.view addSubview:label];
    self.writeWordView.hidden = YES;
    self.writeWordTextField.text = @"";
}

- (IBAction)writeWordBtn:(id)sender {
    self.writeWordView.hidden = !self.writeWordView.hidden;
}
@end
