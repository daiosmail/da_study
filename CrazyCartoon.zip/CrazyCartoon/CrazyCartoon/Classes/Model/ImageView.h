//
//  ImageView.h
//  apartTest
//
//  Created by butterfly on 16/4/11.
//  Copyright © 2016年 butterfly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageViewController.h"
//typedef void(^removeBlock)(UIView* subv);
@interface ImageView : UIImageView
@property(nonatomic,strong)UIView* sview;
//@property(nonatomic,copy)removeBlock remov;

@end
