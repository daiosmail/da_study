//
//  ImageView.m
//  apartTest
//
//  Created by butterfly on 16/4/11.
//  Copyright © 2016年 butterfly. All rights reserved.
//

#import "ImageView.h"
@interface ImageView()<UIGestureRecognizerDelegate>

@property(nonatomic,strong) UIPinchGestureRecognizer* pinch ;
@property(nonatomic,strong)UIRotationGestureRecognizer* rotation;
@property(nonatomic,strong)UIButton* rotationB;
@property(nonatomic,strong)UIButton* panA;

@end

@implementation ImageView
-(UIButton *)rotationB
{
    NSLog(@"zheli");
    if (!_rotationB) {
        _rotationB = [UIButton buttonWithType:UIButtonTypeSystem];
        [_rotationB addTarget:self action:@selector(dragMoving:withEvent:)forControlEvents: UIControlEventTouchDragInside];
        _rotationB.frame = CGRectMake(self.frame.size.width, self.frame.size.height, 30, 30);
        [_rotationB setTitle:@"" forState:UIControlStateNormal];
        _rotationB.userInteractionEnabled = YES;
        NSLog(@"b加载");
    }
    return _rotationB;
}

-(void)dragMoving:(UIButton*)sender withEvent:(UIEvent*)ev
{
    NSLog(@"button");
    sender.center = [[[ev allTouches] anyObject] locationInView:self];
//    self.transform = CGAffineTransformRotate(self.transform, sender.rotation);
}


-(UIView *)sview
{
    if (!_sview) {
        NSLog(@"加载view");
        _sview = [[UIView alloc]init];
        UIButton* b1 =[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
        [b1 setTitle:@"⬇️" forState:UIControlStateNormal];
        [b1 addTarget:self action:@selector(toFront) forControlEvents:UIControlEventTouchUpInside];
        
        UIButton* b2 =[[UIButton alloc]initWithFrame:CGRectMake(30, 0, 40, 30)];
        [b2 setTitle:@"重置" forState:UIControlStateNormal];
        _sview.backgroundColor = [UIColor grayColor];
        [b2 addTarget:self action:@selector(reset) forControlEvents:UIControlEventTouchUpInside];
        
        [_sview addSubview:b1];
        [_sview addSubview:b2];
        _sview.frame = CGRectMake(self.frame.origin.x,self.frame.origin.y -30, 80, 30);

    }
    
    return _sview;
}


-(instancetype)initWithImage:(UIImage *)image
{
    self = [super initWithImage:image];
    self.frame = CGRectMake(0, 0, 50, 50);
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    _rotation = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotation:)];
    _pinch= [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinch:)];
    [self addGestureRecognizer:_pinch];
    [self addGestureRecognizer:_rotation];
    [self addGestureRecognizer:pan];
    self.pinch.delegate = self;
    self.rotation.delegate = self;
    return self;
}


#pragma mark --选定状态下显示选项
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.superview touchesBegan:touches withEvent:event];
    [self addSubview:self.rotationB];
    [self.superview addSubview:self.sview];
    [self.superview bringSubviewToFront:self];
}
#pragma mark --选定下的按键方法
-(void)toFront
{
    [self.superview sendSubviewToBack: self];

}

-(void)reset
{
    self.transform = CGAffineTransformIdentity;
    
}

#pragma mark --选定取消取出状态框
-(void)pinch:(UIPinchGestureRecognizer*)sender
{
//    if (sender.scale > 1) {
//            self.transform = CGAffineTransformScale(self.transform, sender.scale, sender.scale);
//
//        }
//    if (self.frame.size.width >200 & self.frame.size.height>200) {
//        self.transform = CGAffineTransformScale(self.transform, sender.scale, sender.scale);
//    }
//    NSLog(@"%f,%f",self.frame.size.height,self.frame.size.height);
//    if (self.frame.size.height<200) {
//        if (self.frame.size.width > 200) {
//            self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, sender.scale, 200);
//        }
//        
//    }
//    if (self.frame.size.width<200) {
//        if (self.frame.size.height > 200) {
//            self.frame = CGRectMake(self.frame.origin.x, 200, sender.scale, self.frame.origin.x);
//        }
//    }
    self.transform = CGAffineTransformScale(self.transform, sender.scale, sender.scale);
    self.sview.frame = CGRectMake(self.sview.frame.origin.x,self.frame.origin.y -30, 80, 30);

    sender.scale = 1;
}



-(void)rotation:(UIRotationGestureRecognizer*)sender
{
    NSLog(@"动了");
    self.transform = CGAffineTransformRotate(self.transform, sender.rotation);
    
    sender.rotation = 0;
    
}

-(void)pan:(UIPanGestureRecognizer*)sender
{
    
    
    CGPoint translation = [sender translationInView:self];
    self.transform =CGAffineTransformTranslate(self.transform, translation.x, translation.y);
    self.sview.frame = CGRectMake(self.frame.origin.x,self.frame.origin.y -30, 80, 30);
    [sender setTranslation:CGPointZero inView:self];
    
    
}



-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}



@end
