//
//  ImageViewController.m
//  apartTest
//
//  Created by butterfly on 16/4/10.
//  Copyright © 2016年 butterfly. All rights reserved.
//

#import "ImageViewController.h"
#import "ImageView.h"
#import "CCWritingLabel.h"
@interface ImageViewController ()
@property(nonatomic,strong)ImageView* iv;
@property (nonatomic, strong) CCWritingLabel *wLabel;

@end

@implementation ImageViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.view.clipsToBounds = YES;
//    self.view.frame = CGRectMake(10, 100, 380, 588);
    
    NSNotificationCenter* nc =[NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(guotiantian:) name:@"sendMsg" object:nil];
    [nc addObserver:self selector:@selector(writeword:) name:@"writeWord" object:nil];
}
-(void)writeword:(NSNotification*)nf{
    NSLog(@"创建label");
    CCWritingLabel *label = [[CCWritingLabel alloc]initWithFrame:CGRectMake(30, 30, 100, 50)];
    label.text = [nf.userInfo valueForKey:@"word"];
    [self.view addSubview:label];
    label.userInteractionEnabled = YES;
}
-(void)guotiantian:(NSNotification*)nf
{
    NSLog(@"%@",nf.userInfo);
    //NSString* imName = [nf.userInfo valueForKey:@"imageName"];
    UIImage *image = [nf.userInfo valueForKey:@"imageName"];

    ImageView* iv =[[ImageView alloc]initWithImage:image];
    
    [self.view addSubview:iv];
    iv.userInteractionEnabled = YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    for (UIView* a in self.view.subviews) {
        if (![a isKindOfClass:[ImageView class]]) {
            [a removeFromSuperview];
        }
    }
    
}

#pragma mark --添加点击的图片或者文字
//-(void)addViewToSuperView:(NSString*)imageName
//{
//    
//    
//}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
