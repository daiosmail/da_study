//
//  CCWritingLabel.h
//  CrazyCartoon
//
//  Created by Tarena on 16/4/22.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCWritingLabel : UILabel

@end
