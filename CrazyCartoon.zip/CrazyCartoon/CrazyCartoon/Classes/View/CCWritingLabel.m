//
//  CCWritingLabel.m
//  CrazyCartoon
//
//  Created by Tarena on 16/4/22.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "CCWritingLabel.h"

@interface CCWritingLabel ()<UIGestureRecognizerDelegate>
@property(nonatomic,strong) UIPinchGestureRecognizer* pinch ;
@property(nonatomic,strong)UIRotationGestureRecognizer* rotation;
@property(nonatomic,strong)UIButton* rotationB;
@property(nonatomic,strong)UIButton* panA;

@end

@implementation CCWritingLabel

-(UIButton *)rotationB
{
    NSLog(@"zheli");
    if (!_rotationB) {
        _rotationB = [UIButton buttonWithType:UIButtonTypeSystem];
        [_rotationB addTarget:self action:@selector(dragMoving:withEvent:)forControlEvents: UIControlEventTouchDragInside];
        _rotationB.frame = CGRectMake(self.frame.size.width, self.frame.size.height, 30, 30);
        [_rotationB setTitle:@"" forState:UIControlStateNormal];
        _rotationB.userInteractionEnabled = YES;
        NSLog(@"b加载");
    }
    return _rotationB;
}

-(void)dragMoving:(UIButton*)sender withEvent:(UIEvent*)ev
{
    NSLog(@"button");
    sender.center = [[[ev allTouches] anyObject] locationInView:self];
    //    self.transform = CGAffineTransformRotate(self.transform, sender.rotation);
}

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    self.frame = frame;
    self.backgroundColor = [UIColor clearColor];
    self.textColor = [UIColor blackColor];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    _rotation = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotation:)];
    [self addGestureRecognizer:_rotation];
    [self addGestureRecognizer:pan];
    self.pinch.delegate = self;
    self.rotation.delegate = self;
    return self;
}

#pragma mark --选定状态下显示选项
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.superview touchesBegan:touches withEvent:event];
    [self addSubview:self.rotationB];
    [self.superview bringSubviewToFront:self];
}

-(void)rotation:(UIRotationGestureRecognizer*)sender
{
    NSLog(@"动了");
    self.transform = CGAffineTransformRotate(self.transform, sender.rotation);
    
    sender.rotation = 0;
    
}

-(void)pan:(UIPanGestureRecognizer*)sender
{
    
    
    CGPoint translation = [sender translationInView:self];
    self.transform =CGAffineTransformTranslate(self.transform, translation.x, translation.y);
    [sender setTranslation:CGPointZero inView:self];
    
    
}

-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
